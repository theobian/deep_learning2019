
class PoolKernelSizes():
    
    # members: 
    #   TODO

    # methods:
    #   TODO


    def __init__(self, kernelsize_inlay, kernelsize_hidlays, kernelsize_outlay):
        super(PoolKernelSizes, self).__init__()

        self.kernsiz_il = kernelsize_inlay
        self.kernsiz_hls = kernelsize_hidlays
        self.kernsiz_ol = kernelsize_outlay