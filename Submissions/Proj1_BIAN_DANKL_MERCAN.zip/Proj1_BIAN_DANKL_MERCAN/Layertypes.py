
class Layertypes():
    
    # members: 
    #   TODO

    # methods:
    #   TODO


    def __init__(self, layertype_inlay, layertype_hidlays, layertype_outlay):
        super(Layertypes, self).__init__()

        self.laytyp_il = layertype_inlay
        self.laytyp_hls = layertype_hidlays
        self.laytyp_ol = layertype_outlay