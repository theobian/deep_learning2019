
class ActivFuncs():
    
    # members: 
    #   TODO

    # methods:
    #   TODO


    def __init__(self, activfunc_inlay, activfunc_hidlays, activfunc_outlay, activfunc_auxoutlays):
        super(ActivFuncs, self).__init__()

        self.actfunc_inlayer = activfunc_inlay
        self.actfunc_hidlayers = activfunc_hidlays
        self.actfunc_outlayer = activfunc_outlay
        self.actfunc_auxoutlayers = activfunc_auxoutlays