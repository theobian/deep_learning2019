
class Pooltypes():
    
    # members: 
    #   TODO

    # methods:
    #   TODO


    def __init__(self, pooltype_inlay, pooltype_hidlays, pooltype_outlay):
        super(Pooltypes, self).__init__()

        self.pooltyp_il = pooltype_inlay
        self.pooltyp_hls = pooltype_hidlays
        self.pooltyp_ol = pooltype_outlay