
class NPerceptrons():
    
    # members: 
    #   TODO

    # methods:
    #   TODO


    def __init__(self, nperceptr_inlay, nperceptr_hidlays, nperceptr_outlay):
        super(NPerceptrons, self).__init__()
#        self.n_indata = n_indatasize
        self.nperceptr_il = nperceptr_inlay
        self.nperceptr_hls = nperceptr_hidlays
        self.nperceptr_ol = nperceptr_outlay